a = 0.25; 
b = 0.345; 
c = 0.10; 
w = 0.035;
H2max = 0.35; 
H3max = 0.35; 
R = 0.365; 
C1 = 1.0057e-4; 
C2 = 1.1963e-4; 
C3 = 9.8008e-5; 
H10 = 0.1425; 
H20 = 0.1007;
H30 = 0.15; 
q0 = 3.7958e-5; 

% Matris hesaplama için türev işlemleri
syms H1 H2 H3 q

% F1, F2 ve F3 fonksiyonlarının tanımlanması
F1 = (1/(a*w)) * q - (1/(a*w)) * C1 * H1;
F2 = (1/(c*w + (H2/H2max)*b*w)) * C1 * H1 - (1/(c*w + (H2/H2max)*b*w)) * C2 * H2;
F3 = (1/(w*(R - H3max - H3)^2)) * C2 * H2 - (1/(w*(R - H3max - H3)^2)) * C3 * H3;

% A matrisini türev alarak hesaplama
A11 = diff(F1, H1);
A12 = diff(F1, H2); 
A13 = diff(F1, H3);
A21 = diff(F2, H1); 
A22 = diff(F2, H2);
A23 = diff(F2, H3);
A31 = diff(F3, H1);
A32 = diff(F3, H2);
A33 = diff(F3, H3);
A = [A11, A12, A13;
     A21, A22, A23;
     A31, A32, A33];

% B matrisini türev alarak hesaplama
B11 = diff(F1, q);
B21 = diff(F2, q);
B31 = diff(F3, q);
B = [B11;
     B21;
     B31];

% A ve B matrislerinin hesaplanması için işletme noktasını yerine koy
A_num = double(subs(A, [H1, H2, H3, q], [H10, H20, H30, q0]));
B_num = double(subs(B, [H1, H2, H3, q], [H10, H20, H30, q0]));

% C ve D matrisleri
C = eye(3);
D = zeros(3, 1); 

% Sonuçları görüntüle
disp('A matrisi:');
disp(A_num);
disp('B matrisi:');
disp(B_num);
disp('C matrisi:');
disp(C);
disp('D matrisi:');
disp(D);