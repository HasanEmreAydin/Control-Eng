% Parameters Definition (same as Configuration 1)
t = 0:0.01:50;
C10 = 6e-5;
C20 = 1e-5;
C30 = 1e-5; 
% Linearization Matrices for MIMO Configuration
A_v = [
    -C1 / (a * w), 0, 0;
    C1 / (b * w), -(C2 / (c * w + H20 / H2max)), 0;
    0, C2 / (w * (R - H3max - H30)), -C3 / (w * (R - H3max - H30))
];

B_v = [
    -1 / (a * w), 0, 0;
    C1 / (b * w), -(C2 / (c * w + H20 / H2max)), 0;
    0, C2 / (w * (R - H3max - H30)), -C3 / (w * (R - H3max - H30))
];

C_v = eye(3);  % Output matrix
D_v = zeros(3, 3); % Direct transmission matrix

% Display Linearized Matrices for Configuration 2
disp('Linearized Matrices for Configuration 2 (Valve-Controlled System):');
disp('A_v ='); disp(A_v);
disp('B_v ='); disp(B_v);
disp('C_v ='); disp(C_v);
disp('D_v ='); disp(D_v);

%% Open-Loop Simulation for Configuration 2

% Input: Step input for valve settings
valve_input = [1e-5 * (t > 5); 0.5e-5 * (t > 10); 0.2e-5 * (t > 15)];

% State-Space Model for Configuration 2
sys_OL_v = ss(A_v, B_v, C_v, D_v);

% Simulate Open-Loop Response
[y_v, t, x_v] = lsim(sys_OL_v, valve_input', t);

% Plot Results for Configuration 2
figure;
plot(t, y_v(:,1), 'r', 'LineWidth', 1.5); hold on;
plot(t, y_v(:,2), 'g', 'LineWidth', 1.5);
plot(t, y_v(:,3), 'b', 'LineWidth', 1.5);
grid on;
legend('H1 (Upper Tank)', 'H2 (Middle Tank)', 'H3 (Lower Tank)');
xlabel('Time (s)'); ylabel('Water Level (m)');
title('Open-Loop Response: Valve-Controlled System');

%% Save Simulation Data for Configuration 2
save('valve_controlled_case.mat', 'A_v', 'B_v', 'C_v', 'D_v', 't', 'valve_input', 'y_v', 'x_v');

