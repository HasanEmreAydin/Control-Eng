desired_poles = [-2 -3 -1];
K = place(Ap, Bp, desired_poles);
Acl = Ap - Bp * K;
disp(Acl);

% Kapalı döngü kutupları
closed_loop_poles = eig(Acl);
disp('Kapalı döngü kutupları:');
disp(closed_loop_poles);


% Başlangıç koşulları
X0 = [0.15; 0.1; 0.2]; % Tank seviyeleri başlangıç değerleri

% Simülasyon
[t, X] = ode45(@(t, X) Acl * X, [0, 100], X0);

% Zaman tepkisi çizimi
figure;
plot(t, X);
xlabel('Zaman (s)');
ylabel('Tank Seviyeleri (m)');
legend('H1', 'H2', 'H3');
title('Kapalı Döngü Zaman Tepkisi');


% Bozulma etkisi
disturbance = 0.01; % Pompa debisindeki artış
Bp_dist = Bp * disturbance;

% Bozulma ile yeni kapalı döngü sistemi
Acl_dist = Ap - Bp_dist * K;

% Simülasyon
[t_dist, X_dist] = ode45(@(t, X) Acl_dist * X, [0, 100], X0);

% Sonuçların çizimi
figure;
plot(t_dist, X_dist);
xlabel('Zaman (s)');
ylabel('Tank Seviyeleri (m)');
legend('H1', 'H2', 'H3');
title('Bozulma Altında Kapalı Döngü Zaman Tepkisi');
