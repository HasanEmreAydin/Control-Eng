% Parametreler
a = 0.25; 
b = 0.345; 
c = 0.10; 
w = 0.035; 
R2 = 0.365; % Alt tank geometrik parametresi
H3max = 0.35; % Maksimum su seviyesi
H10 = 0.1425; 
H20 = 0.1007; 
H30 = 0.15;
C1 = 1.0057e-4; 
C2 = 1.1963e-4; 
C3 = 9.8008e-5;

% Çalışma noktaları
q0 = C1 * sqrt(H10);  % Pompa giriş debisi
