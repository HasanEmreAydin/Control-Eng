% A ve B Matrisleri (SIMO - Pump Controlled Case)
Ap = [-C1/(2*a*w*sqrt(H10)), 0, 0;
       C1/(2*c*w*sqrt(H10)), -C2/(2*c*w*sqrt(H20)), 0;
       0, C2/(w*(R2-H3max-H30)^2), -C3/(w*(R2-H3max-H30)^2)];

Bp = [1/(a*w); 0; 0];

% Çıkış matrisleri
Cp = eye(3); % Çıktılar H1, H2, H3
Dp = zeros(3,1); % Çıkış bağımlılığı yok
% Kontrol edilebilirlik ve gözlemlenebilirlik
control = rank(ctrb(Ap, Bp));
observe = rank(obsv(Ap, Cp));
